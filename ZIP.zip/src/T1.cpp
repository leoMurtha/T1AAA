#include <stdlib.h>
#include <stdio.h>
#include <set.h> 
#include <algorithm>

int main(int argc, char const *argv[]){
	int N;
	puzzle *p = (puzzle*)malloc(sizeof(puzzle));

	/* N sets de puzzle */
	scanf("%d",&N);

	/* Lendo 4*N sets */
	for(int i = 0; i < N; i++){	
		for (int j = 0; j < 4 ; j++){
			for (int k = 0; k < 4; k++){
				/* Lendo número do piso perdido */
				scanf("%d",&p->sets[j][k]);
				
				/* Piso perdido */					
				if(p->sets[j][k] == 0){
					p->row = j;
					p->col = k;
				}
				//printf("%d ", p->sets[j][k]); 
			}
			//printf("\n");
		}
		printf("POSIÇÃO mst (%d,%d) %d\n", p->row,p->col,p->sets[p->row][p->col]); // verificando, limpar depois
	}

	return 0;
}