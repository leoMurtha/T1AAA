#ifndef _SET_H_
#define _SET_H_

/* Struct representando um set do quebra-cabeça */
typedef struct gameset{
	int sets[4][4];/* Set de pisos */
	int row,col; /* Posição do piso faltando */
}puzzle;

#endif